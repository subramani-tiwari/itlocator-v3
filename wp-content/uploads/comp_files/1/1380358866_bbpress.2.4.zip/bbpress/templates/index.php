<?php

/**
 * Do not put custom themes here. They will be deleted on bbPress updates.
 *
 * Keep custom bbPress themes in /wp-content/themes/
 */
